# Release changes

[Documentation](README.md) · [Full historical German changelog](../../CHANGELOG.md)

## 2.7.1 · 26 November 2026

- Convert hourly VRM Wh correctly to kWh. Repair identifiable 2.7.0 forecasts/blends/errors once with original-value audit, preserving real measurements.
- Select automatic, equal or manual relative source weights, including zero. Configure dependency groups and the automatic cap.
- Latest previews apply settings immediately; daily logs retain frozen weights. A new VRM parser revision excludes bad-unit training statistics.
- Explicit support for battery-free AC PV with automatic measurement-side selection; DC and mixed installations remain supported.
- German/English UI/docs, CSV, regression coverage and repeatable schema-8 migration preventing older unit logic from restarting.

## 2.7.0 · 24 November 2026

- Inline measurement copying with fresh IDs and independent history.
- Multiple measured or RUN-estimated DC loads per hybrid inverter, without aggregate/per-device or AC double counting.
- Configurable automatic residual consumers with names, display settings and consumer-group membership, without independent sensors.
- Device/component wording and consolidated API connection configuration; legacy compatibility retained.
- Saved charts combining raw measurements and computed values with separate unit axes and gaps; independent measurement recording.
- Washing-machine, dryer and dishwasher cycle detection with durable counts, status, pause/minimum-time handling, restart/gap recovery and recorded cycle energy.
- Four private-use PV sources: VRM, Forecast.Solar, Solcast and a local Open-Meteo irradiance model. Persistent request limits, immutable morning forecasts, actual-yield evaluation, validated correction factors, correlated-source families and audited exclusions.
- German/English UI and guides for all additions; CSV includes charts, cycles and forecast configuration without tokens.
- Additive schema 7 preserves existing IDs, history and groups; CSV format remains 1. Startup readiness suppresses expected transient curl errors during updates.

## 2.6.0 — 24 November 2026

- German/English selector with per-browser persistence and explicit lang URL override, including flow-only embedding.
- English navigation, configuration, device/acquisition/group editors, status messages, chart labels, hints, confirmations and built-in installation guide.
- English number/date/calendar formatting without changing site time zone, configuration IDs or history.
- English built-in API diagnostics and period labels via Accept-Language; user-entered names and custom metadata remain unchanged.
- Complete structured English installation, configuration, maintenance and technical documentation alongside German guides.
- Six additional backend language tests and bilingual browser coverage; database schema remains 6, CSV format 1.

## 2.5.0

Generic configurable HTTP GET acquisition with ioBroker, Home Assistant and evcc presets; Basic/Bearer/custom-header authentication; cross-node consumer groups; quiet startup retries with visible final failures. Existing configuration/history preserved through migration to schema 6.

## 2.4.0

Corrected site production/consumption boundaries, period-based self-sufficiency/self-consumption, combined grid metrics and symmetric three-phase completion.

## 2.3.0

DC MPPT total power/energy, hybrid AC boundary modes, direct/estimated converter DC efficiency and related validation/tests.

## 2.2.0 and earlier

Docker deployment and persistence, combined grid tile, signed-power/zero-filter corrections, CSV configuration, nested nodes, separate storage and local recording. Historical release details and exact older test evidence remain in the [full changelog](../../CHANGELOG.md) and [historical test report](../../PRUEFBERICHT.md).
